# py210-template-mailroom-package

## [Assignment Details](https://uwpce-pythoncert.github.io/ProgrammingInPython/exercises/mailroom/mailroom-pkg.html#mailroom-as-a-python-package)
