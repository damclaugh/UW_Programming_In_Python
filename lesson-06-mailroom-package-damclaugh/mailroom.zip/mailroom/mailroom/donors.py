
#!/usr/bin/env python3

# donor list
donor_db = {"Bill Gates": [653772.32, 12.17],
            "MacKenzie Scott": [877.33],
            "Paul Allen": [663.23, 43.87, 1.32],
            "Warren Buffett": [1663.23, 4300.87, 10432.25],
            "Mike Bloomberg": [10786.77, 4567.80, 17.32]
            }